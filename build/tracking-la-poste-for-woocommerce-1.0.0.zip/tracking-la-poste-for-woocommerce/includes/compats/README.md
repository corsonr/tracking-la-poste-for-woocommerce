This directory holds classes to provide compatibilities with other plugins.

## Conventions

* Class name should be `class-wc-la-poste-tracking-{other-plugin-identifier}-compat.php`

